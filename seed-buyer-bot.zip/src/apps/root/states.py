from aiogram.fsm.state import State, StatesGroup


class AgreementDialog(StatesGroup):
    text = State()
    confirm = State()


class UserDialog(StatesGroup):
    profile = State()
    sell = State()


class AddBalanceForm(StatesGroup):
    value = State()
    confirm = State()


__all__ = (
    "AgreementDialog",
    "UserDialog",
    "AddBalanceForm",
)
