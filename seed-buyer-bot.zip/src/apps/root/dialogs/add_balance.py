from typing import *

from aiogram import Bot
from aiogram.types import Message, CallbackQuery
from aiogram_dialog import Window, Dialog, DialogManager
from aiogram_dialog.widgets.input import TextInput
from aiogram_dialog.widgets.kbd import Row, Button, SwitchTo, Back
from aiogram_dialog.widgets.text import Jinja, Const

from src.apps.root import texts
from src.apps.root.states import AddBalanceForm
from src.common import Close
from src.common.factories import *
from src.common.getters import *
from src.common.validators import *
from src.database import User


# region GETTERS
async def value_getter(dialog_manager: DialogManager, **_kwargs: Any) -> Dict[str, Any]:
    return {
        "user": dialog_manager.start_data
    }


async def confirm_getter(dialog_manager: DialogManager, **_kwargs: Any) -> Dict[str, Any]:
    return {
        "user": dialog_manager.start_data,
        "value": dialog_manager.dialog_data["value"]
    }


# endregion

# region ON EVENTS FUNCTIONS
async def on_value_input(_msg: Message, _widget: TextInput, manager: DialogManager, value: float):
    manager.dialog_data["value"] = value
    await manager.next()


async def on_confirm_click(_call: CallbackQuery, _widget: Button, manager: DialogManager):
    user: User = manager.start_data
    value = manager.dialog_data["value"]
    bot: Bot = manager.middleware_data["bot"]
    await user.add_balance(value)
    await bot.send_message(
        chat_id=user.id,
        text=f"<b>💰 На ваш баланс было начислено <code>{value}₽</code></b>"
    )
    await manager.done()


# endregion

# region DIALOGS
dialog = Dialog(
    Window(
        Jinja("<b>💰 Введите сумму, которую хотите начислить для <code>{{ user.id }}</code></b>"),
        TextInput(
            id="value",
            on_success=on_value_input,
            on_error=NumberFactory.on_error,
            type_factory=NumberFactory(
                number_type=float,
                range_validator=RangeValidator(
                    min_value=1,
                    any_error="<b>⚠️ Сумма должна быть больше 1!</b>"
                )
            )
        ),
        Close(texts.cancel),
        state=AddBalanceForm.value,
        getter=value_getter
    ),
    Window(
        Jinja(
            "<b>👤 Для пользователя: <code>id{{ user.id }}</code></b>\n"
            "<b>💰 Сумма: <code>{{ value }}₽</code></b>\n\n"
            "<b>❓ Ты уверен ебать</b>\n"
        ),
        Row(
            Button(texts.yes, id="confirm", on_click=on_confirm_click),
            Close(texts.no)
        ),
        Back(Const("♻️ Ввести другую сумму")),
        state=AddBalanceForm.confirm,
        getter=confirm_getter
    )
)
# endregion
