from typing import *

from aiogram.types import Message
from aiogram_dialog import Window, Dialog, DialogManager, ShowMode, StartMode
from aiogram_dialog.widgets.input import TextInput
from aiogram_dialog.widgets.kbd import SwitchTo, Row, Column
from aiogram_dialog.widgets.text import Jinja, Const

from src.apps.root.states import AgreementDialog, UserDialog
from src.common import Close
from src.common.factories import *
from src.common.getters import *
from src.common.validators import *

from src.apps.root import texts
from src.database import User


# region GETTERS
async def test_getter(**_kwargs: Any) -> Dict[str, Any]:
    return {}


# endregion

# region ON EVENTS FUNCTIONS
async def on_confirm_input(msg: Message, _widget: TextInput, manager: DialogManager, confirm: str):
    if confirm == "Принимаю":
        user: User = manager.middleware_data["user"]
        await user.accept_agreement()
        await manager.start(
            state=UserDialog.profile,
            show_mode=ShowMode.EDIT,
            mode=StartMode.RESET_STACK
        )
    else:
        await msg.reply("<b>⚠️ Неверный ввод!</b>")
# endregion

# region DIALOGS
dialog = Dialog(
    Window(
        Jinja(texts.agreement_text),
        SwitchTo(Const("✅ Принять соглашение"), id="next", state=AgreementDialog.confirm),
        state=AgreementDialog.text,
    ),
    Window(
        Jinja(texts.agreement_confirm),
        TextInput(
            id="confirm",
            on_success=on_confirm_input
        ),
        SwitchTo(texts.back, id="next", state=AgreementDialog.text),
        state=AgreementDialog.confirm,
    )
)
# endregion
