from src.common.app import App

app = App(
    path=__file__,
    default_locale="ru",
    multi_locale=False
)
