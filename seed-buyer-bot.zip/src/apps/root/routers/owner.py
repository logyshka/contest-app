from aiogram import Router, F
from aiogram.types import CallbackQuery
from aiogram_dialog import DialogManager, ShowMode

from src.apps.root.states import AddBalanceForm
from src.common import UserRoleFilter
from src.database import UserRole, User

router = Router()


@router.callback_query(UserRoleFilter(UserRole.OWNER, UserRole.ADMIN), F.data.startswith("add_balance:"))
async def add_balance(call: CallbackQuery, dialog_manager: DialogManager):
    await dialog_manager.start(
        AddBalanceForm.value,
        show_mode=ShowMode.EDIT,
        data=await User.get_or_none(id=call.data.split(":")[1])
    )
