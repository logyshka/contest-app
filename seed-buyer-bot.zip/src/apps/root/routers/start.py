from aiogram import Router
from aiogram.filters import Command
from aiogram.types import Message
from aiogram_dialog import DialogManager, ShowMode

from src.data.config import Config
from src.database import User
from ..states import AgreementDialog, UserDialog

router = Router()


@router.message(Command("start"))
async def start(msg: Message, dialog_manager: DialogManager, user: User, config: Config):
    if not user:
        user = await User.register(
            config=config,
            username=msg.from_user.username,
            user_id=msg.from_user.id
        )
    if user.agreement_accepted:
        await dialog_manager.start(
            state=UserDialog.profile,
            show_mode=ShowMode.EDIT
        )
    else:
        await dialog_manager.start(
            state=AgreementDialog.text,
            show_mode=ShowMode.EDIT
        )

