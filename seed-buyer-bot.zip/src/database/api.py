from tortoise.expressions import *
from tortoise.queryset import QuerySet

from src.data.config import Config
from .enums import *
from .models import *


class User(User):
    @classmethod
    async def register(cls, config: Config, user_id: int, username: str) -> "User":
        user = await cls.get_or_none(id=user_id)

        if user:
            return user

        if user_id == config.global_data.owner_id:
            role = UserRole.OWNER
        elif user_id in config.global_data.admin_ids:
            role = UserRole.ADMIN
        else:
            role = UserRole.USER

        return await cls.create(
            id=user_id,
            username=username,
            role=role
        )

    @classmethod
    async def create_static(cls, config: Config) -> None:
        await cls.filter(id__in=config.global_data.admin_ids).update(role=UserRole.ADMIN)
        await cls.filter(id=config.global_data.owner_id).update(role=UserRole.OWNER)

    @classmethod
    async def search_user(cls, user_id: Union[str, int]) -> Optional["User"]:
        try:
            if user_id[0] == "@":
                user = await User.get_or_none(username=user_id[1:])
            else:
                user = await User.get_or_none(id=user_id[1:])
            return user
        except Exception:
            return None

    @classmethod
    def get_all(cls) -> QuerySet["User"]:
        return cls.filter()

    @classmethod
    def get_admins(cls) -> QuerySet["User"]:
        return cls.filter(Q(role=UserRole.ADMIN) | Q(role=UserRole.OWNER))

    async def update(self, **kwargs) -> None:
        await self.filter(id=self.id).update(**kwargs)

    async def add_balance(self, value: float) -> None:
        self.balance += value
        await self.save()

    async def accept_agreement(self) -> None:
        self.agreement_accepted = True
        await self.save()


__all__ = (
    "User",
)
